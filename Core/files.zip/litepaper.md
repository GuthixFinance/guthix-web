# GUTHIX Protocol Litepaper

> **The Yield-Bearing Liquidity Hub**
> **Version:** 3.1.0
> **Date:** March 2026
> **Status:** 🚧 In Development

---

## Abstract

GUTHIX is a minimalist decentralized liquidity protocol built around a single token: **sgxUSD**.

sgxUSD generates yield from five structurally uncorrelated sources simultaneously — perpetual funding rates, institutional credit yield, real-world asset yield, bridge arbitrage fees, and trading fees. No single source dominates. If one yield source compresses, the others carry the basket. This diversification is structural, not cosmetic.

Users swap in, hold, and appreciate. That is the entire user experience.

Protocol-Owned Liquidity (POL) is deployed across three pool tiers: yield-bearing pools that compound natively alongside sgxUSD, bridge liquidity pools that capture arb fees from cross-chain stablecoin flow, and a USDC entry and exit ramp. All fees and yield flow to sgxUSD NAV appreciation. Zero emissions. Zero dilution. One token.

**Key Principles:**

- **Yield-Bearing Foundation:** sgxUSD is paired against yield-bearing assets from day one. Native collateral yield compounds directly into sgxUSD NAV without harvesting or conversion.
- **Bridge Liquidity Hub:** Deep liquidity for cross-chain stablecoin variants — capturing arb fees as a structurally distinct yield source.
- **Diversified Yield:** Five uncorrelated yield sources. Structural diversification across funding rates, credit yield, RWA yield, bridge arb fees, and trading fees.
- **Pure Real Yield:** 100% of all revenue flows to sgxUSD holders via NAV appreciation. Zero emissions. Zero dilution.
- **Minimalist Architecture:** One token, minimal smart contract surface. No governance tokens, no staking UI, no redemption queues.

---

## Problem Statement

### Fragmented Stablecoin Liquidity
Stablecoin liquidity on Solana is siloed across chains, AMMs, and collateral types. Cross-chain stablecoin variants from Ethereum, BNB Chain, and Polygon exist in meaningful quantities but face thin liquidity, high slippage, and no productive yield. They are stranded capital.

### Single-Source Yield Concentration
Existing yield-bearing stablecoins each expose holders to a single yield source. When funding rates compress, that token's yield compresses. When credit markets tighten, credit yield tightens. Holders have no structural protection against source-specific compression.

### Unsustainable Yield Models
Most protocols subsidize APY with token emissions, creating sell pressure and mercenary capital that exits when rewards end.

### Yield Leakage
Protocols that harvest yield-bearing collateral and convert to base assets destroy compounding. The conversion step is itself a loss — yield that could compound natively is instead taxed at every cycle.

### Complexity Overhead
Redemption queues, multi-token systems, staking UX, and governance voting increase smart contract risk and user friction. Users should not need to manage positions to earn yield.

---

## Solution Overview

| Principle | Benefit |
|-----------|---------|
| **Bridge Liquidity Hub** | Captures bridge arb fees; provides deep cross-chain stablecoin liquidity |
| **Native Compounding** | No conversion tax; maximum yield retention |
| **Diversified Yield** | Structurally uncorrelated sources; yield floor when individual sources compress |
| **Pure Real Yield** | Sustainable APY; no dilution |
| **Minimalist Security** | Reduced audit surface; lower attack vector count |

---

## sgxUSD: The GUTHIX Token

sgxUSD is the sole token of the GUTHIX protocol. Its value starts at $1.00 and floats upward as protocol revenue accrues. It is not pegged. It is not a stablecoin. It is a claim on the GUTHIX protocol that appreciates passively over time.

| Property | Detail |
|----------|--------|
| **Type** | SPL Token (Solana) |
| **Value** | Floats upward from $1.00 as NAV accrues; not pegged |
| **Yield Sources** | Funding rates, credit yield, RWA yield, bridge arb fees, trading fees |
| **Acquisition** | Swap USDC → sgxUSD via Jupiter or app.guthix.finance |
| **Exit** | Swap sgxUSD → USDC or USDT via secondary market |
| **Redemption** | No direct redemption; exits are via secondary market only |
| **Yield Mechanism** | Passive NAV appreciation; no claiming, no staking, no locking |
| **Cross-Chain** | Bridges canonically to Base; yield continues to accrue on both chains |

### Why sgxUSD Over Single-Source Yield Tokens

Holding a single yield-bearing stablecoin gives exposure to one yield source. When that source compresses, yield compresses — with no structural protection.

sgxUSD gives holders exposure to five structurally distinct yield sources in a single token. No individual yield source compression kills sgxUSD's return. And sgxUSD provides collateral utility on Solana lending protocols, cross-chain accessibility to Base, and participation in bridge liquidity fees that no single underlying asset provides.

### sgxUSD as Risk Absorber

Because there is no governance token to absorb protocol-level losses, sgxUSD holders bear the risk of the protocol. In a stress scenario — such as a collateral asset depegging — sgxUSD NAV may compress. This is a deliberate design choice: holders are compensated with real yield for bearing real risk. The protocol makes no guarantee of NAV stability — only that 100% of revenue flows to sgxUSD holders.

### NAV Appreciation and Tax Considerations

sgxUSD expresses all returns as NAV appreciation — a price increase in the token itself rather than a distribution. Depending on jurisdiction and holding period, this may result in different tax treatment compared to yield-distributing tokens. *This is not tax advice. Consult a qualified tax advisor before making any investment decisions based on tax considerations.*

---

## Economic Model

### Core Principle

All protocol revenue flows to sgxUSD holders via NAV appreciation, with zero dilution. There are no token emissions, no emission schedules, and no inflationary rewards.

### Three-Tier Pool Architecture

GUTHIX deploys Protocol-Owned Liquidity across three distinct pool tiers, each serving a different structural role and contributing a different yield stream to sgxUSD NAV.

#### Tier 1 — Yield Engines

sgxUSD is paired directly against yield-bearing stablecoins. Both sides of each pool appreciate natively — no harvesting, no conversion, no yield leakage. The pool itself is the yield mechanism.

| Pool | Yield Source | Swap Fee |
|------|-------------|---------|
| sgxUSD / Funding Rate Asset | Perpetual funding rate yield | 0.10% |
| sgxUSD / Credit Yield Asset | Institutional credit yield | 0.10% |
| sgxUSD / RWA Asset | US Treasury / RWA yield | 0.10% |

**Why no harvesting:** Converting yield-bearing collateral to USDC at every cycle destroys compounding. By pairing sgxUSD directly against these assets, both sides compound natively.

**Why StableSwap:** Yield-bearing stablecoins trade close to their USD value, as does sgxUSD. StableSwap math is efficient within this band.

#### Tier 2 — Bridge Liquidity Hub

GUTHIX provides deep StableSwap liquidity for cross-chain stablecoin variants. These pools serve users unwinding bridge positions and arbitrageurs maintaining cross-chain parity. Yield comes from trading fees generated by constant arb flow.

| Pool | Bridge Source | Swap Fee |
|------|-------------|---------|
| sgxUSD / whUSDC.e | Ethereum | 0.20% |
| sgxUSD / whUSDC.bnb | BNB Chain | 0.20% |
| sgxUSD / whUSDC.poly | Polygon | 0.20% |
| sgxUSD / USDT0 | Cross-chain USDT | 0.05% |

**Why higher fees:** Bridge pairs carry additional risk — bridged assets can depeg independently and require more active monitoring. The fee reflects this risk.

#### Tier 3 — Entry / Exit Ramp

| Pool | Role | Swap Fee |
|------|------|---------|
| sgxUSD / USDC | Entry / exit ramp | 0.05% |

The USDC pool is infrastructure optimized for volume and Jupiter routing. This is the primary pool through which users enter and exit sgxUSD.

### Capital Allocation

| Tier | Allocation |
|------|-----------|
| Yield engines | 50% |
| Bridge hub | 35% |
| Entry / exit ramp | 15% |

### How sgxUSD NAV Grows

sgxUSD NAV appreciates from three compounding streams simultaneously:

**1. Native Collateral Yield (Tier 1)**
Yield-bearing assets appreciate inside the Tier 1 pools independently. As these assets grow, they increase the collateral value backing sgxUSD directly. No keeper action required — this yield is always on.

**2. Bridge Arb Fees (Tier 2)**
Every bridge unwind and cross-chain arb trade generates trading fees that flow to sgxUSD NAV continuously.

**3. Trading Fees (All Tiers)**
All pools earn trading fees from swap activity. These fees compound on top of collateral yield and bridge arb fees.

### Organic Vault Expansion

When users buy sgxUSD on secondary markets, USDC accumulates in the Tier 3 pool. The keeper routes excess USDC into the vault as additional collateral. No new sgxUSD is minted — the collateral backing per existing sgxUSD increases, raising NAV immediately. Every secondary market buy is a direct benefit for all sgxUSD holders.

### Exits

When users sell sgxUSD on secondary markets, POL absorbs the flow. The keeper monitors pool balances and rebalances as needed. There are no redemption queues, no withdrawal delays. Large coordinated exits widen the spread naturally, creating an arbitrage opportunity that incentivizes re-entry.

### Why No Token Emissions

| With Emissions | GUTHIX |
|---|---|
| APY = fees + token inflation | APY = collateral yield + bridge arb fees + trading fees |
| Emissions create sell pressure | No sell pressure |
| Mercenary capital exits when rewards end | Yield seekers hold for compounding |
| Harvest tax destroys compounding | No harvesting; Tier 1 pools compound natively |
| APY collapses at maturity | APY diversified across uncorrelated sources |
| Complex claim/stake UX | Swap in. Hold. Nothing else required. |

---

## Cross-Chain Architecture

sgxUSD is a native Solana token that bridges canonically to Base. On Base, sgxUSD participates in EVM DeFi — usable as collateral, tradeable on Base DEXs, and accessible to EVM users who want yield-bearing exposure without bridging manually.

| Direction | Mechanism | Result |
|-----------|-----------|--------|
| Cross-chain stables → Solana | Tier 2 pools absorb bridged capital | Bridge arb fees → sgxUSD NAV |
| Solana → Base | Canonical lock/mint bridge | sgxUSD accessible to EVM users |
| Base → Solana | Canonical burn/unlock | sgxUSD redeemable on Solana |

---

## Security & Risk Management

### Defense-in-Depth

| Layer | Purpose |
|-------|---------|
| **Minimal code surface** | Smallest possible audit area |
| **Battle-tested dependencies** | Audited infrastructure only; no custom implementations |
| **Off-chain keeper** | Logic upgradable without redeployment; isolated from vault authority |
| **Guardian multisig** | Human oversight for parameter updates and emergency actions; time-locked |
| **Transparency** | Real-time NAV, collateral, and keeper activity on-chain and publicly verifiable |

### Risk Mitigations

| Risk | Mitigation |
|------|-----------|
| **NAV compression** | Diversified yield basket; POL depth ensures exit liquidity |
| **Collateral depeg** | Diversified basket limits single-asset exposure; Guardian pause authority |
| **Bridge asset depeg** | Multiple independent bridge pairs; higher swap fees buffer risk; keeper monitoring |
| **Keeper failure** | Limited signing authority; Guardian override; replaceable by any operator |
| **Regulatory** | sgxUSD framed as vault token; yield expressed as NAV appreciation; no profit guarantees |

### Audit Strategy

- **Phase 1:** Community review
- **Phase 2:** Professional audit pre-mainnet
- **Ongoing:** Bug bounty program; transparent incident response

---

## Roadmap

| Phase | Timeline | Milestones |
|-------|----------|-----------|
| **Core Foundation** | Q2 2026 | Token deployment · Keeper bot · All pools on devnet · Community audit |
| **Mainnet Launch** | Q3 2026 | Professional audit complete · POL seeding · Jupiter integration |
| **Multichain** | Q4 2026 | sgxUSD on Base · Lending protocol integrations · Analytics dashboard |
| **Decentralization** | Q1 2027 | Guardian Council · Multiple keeper operators · Safety fund |

---

## Ecosystem Integrations

### Collateral Partners

The yield-bearing and bridge pools are launch requirements. Each collateral partner seeds their respective pool, gains Jupiter routing across Solana, and earns trading fees on seeded capital.

### Infrastructure Partners

| Partner | Integration |
|---------|------------|
| **Meteora** | StableSwap pools for all sgxUSD pairs |
| **Wormhole** | Canonical cross-chain bridge |
| **Jupiter** | Aggregator routing for all sgxUSD pairs |
| **Kamino / MarginFi** | sgxUSD as lending collateral |
| **Squads** | Guardian multisig governance |

---

## Getting Involved

**For collateral partners:** GUTHIX is seeking co-seeding partners for yield-bearing and bridge pools at launch. Each partner seeds their respective pool, gains Jupiter routing distribution, and earns trading fees on seeded capital. Contact: partnerships@guthix.finance

**For users:** Swap USDC → sgxUSD on Jupiter or via app.guthix.finance. Hold. Bridge to Base if desired.

**For developers:** See the GitHub repository for contracts, keeper source, and contribution guidelines.

---

## Disclaimer

*This document is for informational purposes only and does not constitute financial advice, investment recommendations, or an offer to sell or solicitation to buy any securities, tokens, or financial instruments. GUTHIX is a decentralized protocol operating on a best-efforts basis. sgxUSD is a vault token whose value floats and is not guaranteed to appreciate. Participants acknowledge they are using the software at their own risk. Cryptocurrency investments are volatile and high-risk. Consult qualified legal, financial, and tax advisors before participating.*

---

## License

This litepaper is licensed under the **MIT License**.

---

*© 2026 GUTHIX Protocol. One token. Five yield sources. Built on DeFi.*
