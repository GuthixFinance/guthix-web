# GUTHIX Protocol: Risk Disclosures

> **Document Version:** 1.1.0
> **Last Updated:** March 2026
> **Status:** 🚧 Experimental / Public Disclosure
> **Applies To:** sgxUSD vault token, GUTHIX Protocol smart contracts, all protocol interfaces

---

## ⚠️ Critical Warning

**GUTHIX Protocol is experimental software provided "AS-IS" and "AS-AVAILABLE." By accessing or using the protocol, you acknowledge and accept ALL risks described below. If you do not understand or accept these risks, DO NOT use this protocol.**

**sgxUSD is NOT:**
- ❌ A stablecoin (value floats; not pegged to any asset)
- ❌ Insured (no FDIC, SIPC, or government backing)
- ❌ A bank deposit or savings account
- ❌ Guaranteed to maintain or increase in value
- ❌ Redeemable at a fixed price
- ❌ Regulated as a traditional financial product in most jurisdictions

**You may lose some or all of your investment. Past performance does not indicate future results.**

---

## Table of Contents

1. [Protocol Overview](#protocol-overview)
2. [General Risk Acknowledgments](#general-risk-acknowledgments)
3. [Specific Risk Categories](#specific-risk-categories)
4. [Jurisdictional Risks](#jurisdictional-risks)
5. [Tax Implications](#tax-implications)
6. [No Warranties or Guarantees](#no-warranties-or-guarantees)
7. [Limitation of Liability](#limitation-of-liability)
8. [User Responsibilities](#user-responsibilities)
9. [Updates to This Document](#updates-to-this-document)

---

## Protocol Overview

### What is GUTHIX Protocol?

GUTHIX Protocol is a decentralized, non-custodial liquidity hub that issues **sgxUSD** — a vault token that appreciates passively as fees and yield accrue across the protocol's liquidity pools.

### How Does It Work?

- Users swap USDC or USDT for sgxUSD via automated smart contracts
- Protocol-owned liquidity is deployed across yield-generating pools
- Yield accrues as NAV (Net Asset Value) appreciation
- Users exit by swapping sgxUSD back to USDC or USDT on secondary markets
- No redemption queue; no guaranteed exit price

### Key Characteristics

| Feature | Description |
|---------|-------------|
| **Non-Custodial** | Users retain wallet custody; protocol holds liquidity in pools |
| **Permissionless** | Anyone can interact (subject to legal restrictions) |
| **Transparent** | All transactions, pool balances, and NAV visible on-chain |
| **Experimental** | Research-stage software; not production-grade financial infrastructure |

---

## General Risk Acknowledgments

By using GUTHIX Protocol, you expressly acknowledge and accept that:

1. **Cryptocurrency investments are highly speculative and volatile**
2. **You are solely responsible for your investment decisions**
3. **You have the financial sophistication to understand these risks**
4. **You can afford to lose all funds you commit to the protocol**
5. **No one associated with GUTHIX is responsible for your losses**
6. **Regulatory environments are uncertain and may change adversely**
7. **This is not financial, legal, or tax advice**

---

## Specific Risk Categories

### 1. Smart Contract Risk

**Description:** GUTHIX operates via smart contracts. Despite audits and testing, code may contain bugs, vulnerabilities, or exploits.

**Potential Impacts:**
- Total or partial loss of funds
- Protocol malfunction or shutdown
- Unauthorized access or theft
- Unintended behavior from upgrades or interactions

**Mitigations (Not Guarantees):**
- Professional audit pre-mainnet
- Bug bounty program
- Minimalist code design
- Guardian emergency controls

**Residual Risk:** **HIGH** — Audits reduce but do not eliminate smart contract risk.

---

### 2. Market & Volatility Risk

**Description:** sgxUSD NAV floats based on the performance of underlying yield-bearing assets and trading volumes. Values can increase or decrease.

**Potential Impacts:**
- NAV depreciation below entry price
- Yield source compression or failure
- Correlation convergence during market stress
- Permanent capital loss

**Yield Sources & Risks:**

| Source | Risk Profile |
|--------|-------------|
| **Funding Rate Yield** | Funding rate volatility; delta-hedging failure |
| **Credit Yield** | Credit defaults; borrower insolvency |
| **RWA Yield** | Asset valuation uncertainty; regulatory action |
| **Trading Fees** | Volume dependency; impermanent loss |
| **Bridge Arbitrage** | Cross-chain volatility; bridge failures |

**Residual Risk:** **HIGH** — Yield is not guaranteed; NAV may decrease.

---

### 3. Counterparty & Protocol Risk

**Description:** GUTHIX depends on external protocols for yield generation and infrastructure. Their failure directly impacts sgxUSD.

**Potential Impacts:**
- Collateral asset depegging or insolvency
- Smart contract exploits in integrated protocols
- Governance attacks on partner protocols
- Regulatory shutdown of yield sources

**Residual Risk:** **HIGH** — Diversification reduces but does not eliminate counterparty risk.

---

### 4. Liquidity Risk

**Description:** Exits occur via secondary market swaps, not direct redemption. Liquidity may be insufficient during stress.

**Potential Impacts:**
- High slippage on exits during volatility
- Inability to exit at fair value
- Protocol-Owned Liquidity depletion
- Cascading pressure during market panic

**No Redemption Guarantee:**
- ❌ No redemption queue
- ❌ No guaranteed exit price
- ❌ No liquidity backstop beyond POL

**Residual Risk:** **MEDIUM-HIGH** — POL depth helps but cannot guarantee liquidity in extreme scenarios.

---

### 5. Price Feed Risk

**Description:** NAV calculations depend on external price feeds. Feed failures or manipulation affect protocol operations.

**Potential Impacts:**
- Incorrect NAV pricing
- Exploitable arbitrage opportunities
- Collateral misvaluation

**Mitigations:**
- Multiple redundant price feeds
- Time-weighted average prices (TWAP)
- Deviation circuit breakers
- Guardian pause authority

**Residual Risk:** **MEDIUM** — Redundancy helps but manipulation remains possible.

---

### 6. Cross-Chain & Bridge Risk

**Description:** sgxUSD bridges to Base via Wormhole NTT. Bridge transactions carry additional risks beyond native Solana operations.

**Potential Impacts:**
- Bridge smart contract exploits
- Transaction finality delays or failures
- Asset loss during bridge transfer
- Regulatory complications across chains

**Note:** Cross-chain bridges are a historically high-risk category in DeFi. Bridge exploits have resulted in significant losses across the industry. Do not bridge more than you can afford to lose.

**Residual Risk:** **MEDIUM-HIGH** — Bridges are complex and historically vulnerable.

---

### 7. Regulatory & Legal Risk

**Description:** Cryptocurrency regulations vary by jurisdiction and change frequently.

**Potential Impacts:**
- Access restrictions or geo-blocking
- Token classification as security or regulated instrument
- Tax treatment changes
- Enforcement actions

| Jurisdiction | Status |
|--------------|--------|
| **United States** | SEC/CFTC jurisdiction unclear; state-level variations |
| **European Union** | MiCA framework evolving |
| **Singapore** | PSA Digital Payment Token classification |
| **Other** | Many jurisdictions lack clear guidance |

**Residual Risk:** **HIGH** — Regulatory landscape is fluid and enforcement is unpredictable.

---

### 8. Operational & Keeper Risk

**Description:** Protocol functions depend on off-chain Keeper services for NAV updates, rebalancing, and fee routing.

**Potential Impacts:**
- Keeper downtime or failure
- Delayed NAV updates
- Suboptimal rebalancing

**Mitigations:**
- Limited keeper vault authority
- Guardian multisig oversight
- Keeper decentralization roadmap

**Residual Risk:** **LOW-MEDIUM** — Operational risks are managed but not eliminated.

---

### 9. Governance & Multisig Risk

**Description:** Guardian multisig holds limited emergency powers — pause and config updates only.

**Potential Impacts:**
- Multisig key compromise
- Coordinated malicious action by signers
- Governance centralization concerns

**Safeguards:**
- Limited scope (no direct fund withdrawal)
- Time-locked config changes
- Decentralization roadmap

**Residual Risk:** **LOW-MEDIUM** — Powers are limited but centralization exists at launch.

---

### 10. Technology & Infrastructure Risk

**Description:** Protocol depends on underlying infrastructure including the Solana blockchain, RPC providers, and frontend hosting.

**Potential Impacts:**
- Network outages or congestion
- RPC provider failures
- Frontend downtime
- DNS hijacking or phishing

**Residual Risk:** **MEDIUM** — Infrastructure risks are largely external and uncontrollable.

---

### 11. Tax & Accounting Risk

**Description:** Tax treatment of sgxUSD transactions is uncertain and varies by jurisdiction.

**Common Considerations:**
- Swaps (USDC → sgxUSD) may be taxable events
- NAV appreciation may be taxed as income or capital gains
- Bridge transactions may trigger additional reporting
- Yield accrual timing (realized vs. unrealized) is unclear

**Residual Risk:** **HIGH** — Tax treatment is jurisdiction-specific and evolving.

---

### 12. Experimental & Development Risk

**Description:** GUTHIX is experimental software in active development. Features and parameters may change.

**Potential Impacts:**
- Protocol changes affecting your position
- Undiscovered bugs in new code
- Parameter adjustments (fees, allocations, limits)
- Complete protocol shutdown

**Residual Risk:** **MEDIUM-HIGH** — Experimental status means higher uncertainty.

---

## Jurisdictional Risks

**Cryptocurrency regulations vary significantly by jurisdiction. You are solely responsible for understanding and complying with laws applicable to your location.**

| Jurisdiction | Specific Concerns |
|--------------|------------------|
| **United States** | SEC securities enforcement; state money transmitter laws; tax reporting complexity |
| **New York** | BitLicense requirements |
| **China** | Cryptocurrency transactions prohibited |
| **Other** | Many jurisdictions lack clear guidance; assume risk if unclear |

### Sanctions & Restricted Parties

**You may NOT use GUTHIX Protocol if you are:**
- Located in a sanctioned jurisdiction (OFAC, UN, EU lists)
- A sanctioned individual or entity
- Using the protocol for illicit purposes

---

## Tax Implications

**Tax treatment of GUTHIX Protocol participation is complex and uncertain. Consult a qualified tax advisor in your jurisdiction.**

| Event | Potential Tax Treatment |
|-------|----------------------|
| **USDC → sgxUSD swap** | Taxable exchange (capital gain/loss on USDC) |
| **sgxUSD NAV appreciation** | Unrealized gain or income — jurisdiction-dependent |
| **sgxUSD → USDC swap** | Taxable event (capital gain/loss on sgxUSD) |
| **Bridge transactions** | Potentially taxable; jurisdiction-dependent |

---

## No Warranties or Guarantees

**GUTHIX Protocol is provided "AS-IS" and "AS-AVAILABLE" without warranties of any kind.**

The following are expressly NOT guaranteed:
- NAV stability or appreciation
- Yield generation or APY
- Liquidity availability
- Smart contract security
- Regulatory compliance
- Protocol longevity

---

## Limitation of Liability

**In no event shall GUTHIX Protocol, its contributors, developers, auditors, partners, or any affiliated parties be liable for any direct, indirect, incidental, special, or consequential damages arising from or related to protocol participation.**

**If liability cannot be excluded under applicable law, the total aggregate liability shall not exceed the amount of fees paid by you to the protocol (if any) or $100 USD, whichever is greater.**

**You agree to indemnify and hold harmless GUTHIX Protocol and all affiliated parties from claims, liabilities, or expenses arising from your use of the protocol, violation of these terms, or violation of applicable laws.**

---

## User Responsibilities

By using GUTHIX Protocol, you agree to:

- Comply with all applicable laws and regulations in your jurisdiction
- Report and pay all applicable taxes
- Read and understand all documentation before participating
- Secure your private keys and seed phrases
- Verify contract addresses before transacting
- Accept all risks described in this document

---

## Updates to This Document

This document is versioned and may be updated periodically.

| Version | Date | Changes |
|---------|------|---------|
| `1.1.0` | Mar 2026 | Removed partner-specific impact estimates; updated bridge risk language |
| `1.0.0` | Mar 2026 | Initial public risk disclosure |

**Your continued use of GUTHIX Protocol after changes constitutes acceptance of the updated terms.**

---

*© 2026 GUTHIX Protocol. This document is licensed under MIT License.
Last Updated: March 2026 | Version: 1.1.0
Use at your own risk.*
