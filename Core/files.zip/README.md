# GUTHIX Protocol

> **The Yield-Bearing Liquidity Hub**
> **Version:** 3.1.0
> **Status:** 🚧 In Development

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Solana](https://img.shields.io/badge/Solana-Anchor-9945FF.svg?logo=solana)](https://solana.com)
[![Base](https://img.shields.io/badge/Base-EVM-0052FF.svg?logo=base)](https://base.org)

---

## Overview

**GUTHIX** is a minimalist decentralized liquidity protocol built around a single token: **sgxUSD**.

sgxUSD generates yield from five structurally uncorrelated sources simultaneously — perpetual funding rates, institutional credit yield, real-world asset yield, bridge arbitrage fees, and trading fees. No single source dominates. If one yield source compresses, the others carry the basket.

Users swap in, hold, and appreciate. That is the entire user experience.

No governance tokens. No token emissions. No staking UI. No redemption queues. One token, passive yield.

### Key Features

- **Yield-Bearing Foundation:** sgxUSD is paired against yield-bearing assets from day one. Native collateral yield compounds directly into sgxUSD NAV — no harvesting, no conversion, no yield leakage.
- **Bridge Liquidity Hub:** Deep StableSwap pools for cross-chain stablecoin variants — capturing bridge arb fees as a structurally distinct yield source.
- **Diversified Yield:** Five uncorrelated yield sources. Funding rates, credit yield, RWA yield, bridge arb fees, and trading fees compound simultaneously.
- **Pure Real Yield:** 100% of all revenue flows to sgxUSD holders via NAV appreciation. Zero emissions. Zero dilution.
- **Minimalist Security:** Single custom Anchor program. Governance via Squads Multisig. Canonical cross-chain bridge.
- **Cross-Chain:** sgxUSD bridges canonically to Base — accessible to EVM users without manual bridging.

---

## Architecture

### Pool Structure

| Tier | Pool | Role | Swap Fee |
| :--- | :--- | :--- | :--- |
| **Yield** | sgxUSD / Funding Rate Asset | Perpetual funding rate yield | 0.10% |
| **Yield** | sgxUSD / Credit Yield Asset | Institutional credit yield | 0.10% |
| **Yield** | sgxUSD / RWA Asset | Real-world asset yield | 0.10% |
| **Bridge** | sgxUSD / whUSDC.e | Ethereum bridge arb fees | 0.20% |
| **Bridge** | sgxUSD / whUSDC.bnb | BNB Chain bridge arb fees | 0.20% |
| **Bridge** | sgxUSD / whUSDC.poly | Polygon bridge arb fees | 0.20% |
| **Bridge** | sgxUSD / USDT0 | Cross-chain USDT arb fees | 0.05% |
| **Ramp** | sgxUSD / USDC | Entry / exit only | 0.05% |

### Component Overview

| Component | Implementation | Responsibility |
| :--- | :--- | :--- |
| **Core Logic** | `guthix-core` (Anchor) | Collateral locking, NAV calculation, sgxUSD minting/burning |
| **Governance** | Squads Protocol (Multisig) | Parameter updates, emergency controls |
| **Token** | SPL Token | sgxUSD vault token |
| **Bridging** | Wormhole NTT | Canonical lock/mint across Solana ↔ Base |
| **Liquidity** | Meteora StableSwap | Protocol-Owned Liquidity across all pools |
| **Maintenance** | Off-Chain Keeper (TypeScript) | NAV updates, POL rebalancing, pool monitoring |

---

## Getting Started

### Prerequisites

- **Rust** (latest stable)
- **Solana Tool Suite** (v1.16+)
- **Anchor Framework** (v0.29+)
- **Node.js** (v20+)
- **npm**

### Installation

```bash
git clone https://github.com/guthix-protocol/guthix-core.git
cd guthix-core

# Build program
cargo build-bpf

# Install client dependencies
cd client && npm install
```

### Local Development

```bash
# Start local validator
solana-test-validator

# Deploy to devnet
anchor deploy --provider.cluster devnet

# Run tests
anchor test
```

---

## Repository Structure

```text
guthix-core/
├── programs/
│   └── guthix-core/       # Core program (Vault + Config + NAV)
├── clients/
│   ├── sdk/               # TypeScript SDK
│   └── keeper/            # Keeper bot (NAV updates + POL rebalancing)
├── scripts/
│   ├── deploy-squads.ts   # Setup Guardian Multisig
│   └── init-core.ts       # Initialize Vault Program
├── tests/
│   └── guthix-core.test.ts
├── Anchor.toml
├── Cargo.toml
└── README.md
```

---

## Keeper Bot

The off-chain Keeper manages NAV updates and POL rebalancing. All operations are signed with limited vault authority — the Keeper holds no privileged mint authority.

### Setup

```bash
cd clients/keeper
npm install
cp .env.example .env
# Set HELIUS_API_KEY, KEEPER_PRIVATE_KEY, MANIFEST_MARKET_ADDRESS, SGXUSD_MINT
npm run dev
```

### Responsibilities

| Task | Trigger |
| :--- | :--- |
| **Update sgxUSD NAV** | Collateral yield accrual + fee collection |
| **Pool rebalancing** | Inventory drift beyond threshold |
| **Bridge pool monitoring** | Cross-chain asset depeg detection |
| **Vault solvency check** | Continuous |

---

## Security

### Defense-in-Depth

| Layer | Purpose |
| :--- | :--- |
| **Minimal code surface** | Smallest possible audit area |
| **Standard dependencies** | Battle-tested, audited infrastructure only |
| **Off-chain keeper** | Logic upgradable without redeployment; limited vault authority |
| **Guardian multisig** | Human oversight; emergency pause; time-locked config updates |
| **Transparency** | Real-time NAV, collateral, and keeper activity on-chain |

### Audit Status

| Audit | Status | Expected |
| :--- | :--- | :--- |
| **Community Review** | 🚧 Open | Ongoing |
| **Professional Audit** | 🚧 Planned | Q3 2026 |
| **Bug Bounty** | 🚧 Planned | Post-mainnet |

### Reporting a Vulnerability

Do not open public issues for security vulnerabilities. Report directly to **security@guthix.finance**.

---

## Contributing

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/your-feature`)
3. Commit changes (`git commit -m 'Add your feature'`)
4. Push and open a Pull Request

All new features must include tests. Run `cargo fmt` before committing. See [CONTRIBUTING.md](./CONTRIBUTING.md) for full guidelines.

---

## Roadmap

| Phase | Timeline | Milestones |
| :--- | :--- | :--- |
| **Core Foundation** | Q2 2026 | Devnet deployment · Keeper MVP · Community audit |
| **Mainnet Launch** | Q3 2026 | Professional audit · POL seeding · Jupiter integration |
| **Multichain** | Q4 2026 | sgxUSD on Base · Lending integrations · Analytics dashboard |
| **Decentralization** | Q1 2027 | Guardian Council · Multiple keeper operators · Safety fund |

---

## License

MIT License — see [LICENSE](./LICENSE) for details.

---

## Disclaimer

*This repository is for informational purposes only and does not constitute financial advice or an offer to buy or sell any securities. sgxUSD is a vault token whose value floats and is not guaranteed to appreciate. Participants use the software at their own risk. Consult a qualified financial advisor before making any investment decisions.*

---

## Contact

- **Website:** [www.guthix.finance](https://www.guthix.finance)
- **Twitter:** [@GuthixProtocol](https://twitter.com/GuthixProtocol)
- **Partnerships:** [partnerships@guthix.finance](mailto:partnerships@guthix.finance)
- **Security:** [security@guthix.finance](mailto:security@guthix.finance)

---

*© 2026 GUTHIX Protocol. One token. Five yield sources. Built on DeFi.*
